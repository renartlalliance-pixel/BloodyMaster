# Édition installable de test — 10 novembre 2026

Installateur NSIS 3.11 amd64, vrai VST3 et outil WAV Windows x64 générés.
Build testé : JUCE 7.0.12 / MinGW-w64 GCC 14, runtimes statiques ; pas de DLL
MinGW externe à installer. Le build MSVC/JUCE 8 par défaut reste non exécuté ici.

- 8/8 suites Windows exécutées sous Wine 10 : utilitaires, JUCE (9 groupes,
  0 échec), EQ, dynamique/crêtes, transitions OS, comportements, presets et hôte VST3.
- VST3 indépendant : chargement de la factory, instanciation, stéréo et traitement
  de 8 192 échantillons à 48 kHz ; latence 336, sortie finie et non silencieuse.
- 31 essais WAV avec le binaire Windows sous Wine : formats, Unicode, collisions,
  données invalides et conservation des entrées.
- Installation silencieuse, installation répétée, désinstallation et réinstallation
  vérifiées dans Wine ; DLL installée identique au build, fichier tiers conservé.
- Éditeur de test rendu et inspecté ; 32 contrôles actifs, neuf presets,
  indicateurs réels via atomiques entre audio et UI. Aucun paramètre inactif affiché.
- Ressources HTML UI/Reference toujours identiques à la référence approuvée.

À vérifier sur Windows natif/FL Studio : UAC, scan de l'hôte, interaction graphique,
audio temps réel, performances et sauvegarde/reprise d'une session réelle. Le
binaire n'est pas signé. L'HTML et les DSP encore absents ne sont pas présentés
comme terminés. Le rapport courant est `docs/INSTALLER_VALIDATION.json`.

---

Historique :

# Dernière validation — DSP et presets, 10 novembre 2026

Six suites CTest DSP réussies : EQ/filtres/stéréo, utilitaires dB, dynamique/crêtes,
changements de suréchantillonnage, comportements inspirés de l'analogique, presets.
Les sources du plugin JUCE et leurs nouveaux tests n'ont pas été compilés ici.

- Tests existants : 76 272 assertions EQ, 9 665 dynamique/crêtes,
  417 100 vérifications des transitions OS.
- Nouveaux comportements : 25 032 vérifications (continuité/monotonie du coude,
  sidechain, récupération optical, ratio unitaire, liaison et clipper).
- Banque : 9 presets, 108 rendus stéréo (4 Fs × 3 OS × 9).
- Mesures indépendantes 32× : 72 exports presets et 60 vecteurs généraux réussis.
  Pire crête : −1,1158317481592677 dBTP (campagne générale),
  −1,1177306365326098 dBTP (presets), plafond −1 dB.
- Repliement 13 kHz sur le signal du test : réduction 78,73727699276319 dB.
- Tests WAV : 31 exécutions réussies, formats/Unicode/collisions/entrées invalides.
- ASan/UBSan : EQ, dynamique, changements OS et banque réussis ; détection des
  fuites désactivée. Les nombres incluent des vérifications par échantillon.
- Outil WAV Windows reconstruit depuis les dernières sources ; pas exécuté sous
  Windows. Aucun VST3 Windows ni test FL Studio validé.
- HTML UI/Reference : SHA-256 toujours identique à la référence approuvée.

Presets : `docs/PRESETS_FR.md`, banque `Source/Presets/FactoryPresets.h`, export
`Resources/FactoryPresets.json`. Accessibles dans l'outil WAV et déclarés comme
programmes JUCE (rappel hôte et état à vérifier sous Windows). Le HTML reste
non raccordé. Les valeurs initiales HTML restent les défauts du plugin jusqu'au
rappel explicite d'un programme. Les programmes ne réinitialisent que les
32 paramètres DSP actifs ; les commandes inactives gardent leur état sans effet.

Ces tests ne valident pas une équivalence sonore avec du matériel. Les écarts sont
consignés dans `docs/ANALOG_AUDIT_FR.md`. Aucun morceau utilisateur, capture de
machine ou écoute humaine n'a été utilisé. Les programmes sont originaux ; les
liens d'inspiration ne constituent pas des réglages chiffrés d'ingénieurs connus.
Le rapport actuel est `docs/RETEST_PRESETS.json`. Les valeurs de campagnes plus
anciennes ci-dessous sont historiques et antérieures aux derniers presets/LPF.

---

# État réel — reprise M3, 10 novembre 2026

## Modifications de cette reprise

- Audit des sources transférées et vérification SHA-256 des deux HTML approuvés.
- Lecteur WAV : rejet des tailles RIFF incohérentes, en-têtes/chunks/padding tronqués
  et chunks fmt/data dupliqués ; conservation des formats déjà acceptés.
- Nouveau test d'intégration WAV indépendant du code de lecture : PCM 16/24/32,
  float32/64, mono/stéréo, noms Unicode, collisions, entrées invalides et intégrité
  des sources (31 exécutions).
- Ajout du test DbUtils au projet CMake DSP autonome.
- Workflow Windows : tests WAV et publication de l'outil WAV comme artefact.
- README actualisé. Les transferts statiques M3 sont conservés ; le changement de mode OS est maintenant lissé.

## Vérifié ici sous Linux

- g++ 14.2, C++20, optimisation, avertissements stricts : outil WAV et tests compilés.
- CTest autonome : 4/4 réussis. Changement OS : 417 100 vérifications à quatre Fs,
  correspondance du fondu avec deux chaînes de référence, latence, plafond échantillon,
  silence et changements rapides. ASan/UBSan du changement OS également réussis
  (détection des fuites désactivée). EQ : 76 272 assertions ; dynamique : 9 665 ; DbUtils OK.
- ASan/UBSan dynamique/crêtes : 9 665 assertions réussies, détection des fuites
  désactivée. Cette exécution ne valide pas les fuites mémoire.
- Validation indépendante NumPy/SciPy : 60 vecteurs, 44,1/48/96/192 kHz,
  suréchantillonnage 2/4/8×, plafond −1 dB. Pire crête reconstruite à 32× :
  −1,2271478927513255 dBTP. Réduction du repliement à 13 kHz :
  78,75039574795527 dB sur le signal décrit dans validate_audio.py.
- Bypass exporté bit-exact et intégrité des sources vérifiés dans cette campagne.
- Tests WAV : 31/31 réussis après correction.
- HTML UI et Reference : c48de97f75130c18aa8aef1f766e5be5652254fbf0da1a96fcf91d37761a83ff.

Les comptes d'assertions incluent des comparaisons par échantillon. Les résultats
ne constituent pas une garantie universelle de plafond true peak ou de qualité.

## Limites constatées

- Configuration du plugin JUCE Linux tentée : JUCE récupéré, mais juceaide bloque
  sur X11/Xlib.h absent ; ALSA, FreeType/fontconfig et OpenGL manquent également.
  L'installateur système cloud recommandé n'est pas présent dans cet environnement.
- Outil WAV Windows reconstruit par compilation croisée Zig 0.13 ; pas d'exécution
  Windows, pas d'essai de la boîte de dialogue Windows ni de test FL Studio.
- Aucun VST3 Windows compilé ; aucun lancement des workflows GitHub Actions.
- Interface JUCE générique ; HTML conservé mais non intégré.
- Oversampling du plugin maintenant modifiable pendant la lecture : modes préalloués,
  préchauffage puis fondu 20 ms, latence constante. Un seul mode tourne hors transition.
  Le raccordement JUCE a été modifié et un test plugin ajouté ; ce test JUCE n’a pas
  été exécuté ici faute de dépendances système.
- Valve sélectionne un relâchement optical, sans modèle de lampe ; trim sert de
  plafond. La chaîne a une latence 192 + ceil(Fs × 0,003) échantillons.
- De-esser, résonances, THD/XL, profils, Stereo Enhance, LUFS et A/B compensé restent
  à développer. Des paramètres visibles sont encore inactifs.
- Pas d'écoute humaine comparative ni de mesure CPU dans un DAW.

## Suite

Compiler et exécuter sous Windows les tests et l'outil WAV ; valider le VST3 et son
bypass/automation dans un hôte, puis FL Studio. Finaliser ensuite l'intégration
HTML et les fonctions restantes, en gardant la référence visuelle intacte.
