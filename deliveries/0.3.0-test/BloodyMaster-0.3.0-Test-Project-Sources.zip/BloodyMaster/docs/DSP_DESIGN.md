# DSP M2a — conception et correspondance des commandes

L'interface utilisateur reste strictement identique. Les 42 IDs APVTS de M1 sont conservés. Ce jalon raccorde 18 IDs au moteur ; les autres attendent les étapes suivantes.

## Courbes de couleur inspirées du Pultec

L'inspiration fonctionnelle est le boost grave combiné à une atténuation à courbe différente, ainsi que le boost aigu large. Il ne s'agit pas d'une copie du DSP d'un produit commercial, d'une modélisation de circuit, ni d'une reproduction mesurée d'un Pultec. Pas de saturation, lampe ou transformateur dans cette étape. La réponse neutre reste neutre.

Pour conserver une interface simple, le couplage grave est automatique dans le bouton Sub Weight, sans nouvelle commande.

| Commande HTML / ID | Traitement M2a |
|---|---|
| Sub Weight / bm_bass | Valeur g positive : shelf 60 Hz à 1,45g dB + shelf 240 Hz à −0,45g dB. Gain asymptotique grave g, léger creux au-dessus du grave. Valeur négative : shelf 60 Hz seul. |
| Punch Body / bm_mid | Cloche 650 Hz, Q 0,7, gain signé. |
| Silk Shine / bm_high | Cloche large 8 kHz, Q 0,55, gain signé. |
| Air Diffuse / bm_presence | Plateau 12 kHz, gain signé ; permet notamment d'atténuer le haut tout en renforçant la cloche aiguë. |
| Gravity / bm_foundation | Plateau 160 Hz, 0,3 dB par unité, soit ±3 dB. |
| bm_p1f/p1g, p2f/p2g, p3f/p3g | Trois cloches correctives, Q fixe 1. Gains et fréquences de M1. |
| bm_eq_active | Active/désactive les trois bandes paramétriques avec lissage ; ne désactive pas la section Tone. |
| bm_hpf / bm_lpf | Butterworth 12 dB/octave, Hz / kHz convertis en Hz. |
| bm_monomaker | Passe-haut Butterworth sur le canal Side, 0 Hz désactive ce filtre. Réduction progressive de la stéréo dans le grave, pas une coupure absolue. |
| bm_width | Side × largeur/100, 100 % neutre. Mid inchangé. |
| bm_pan | Balance par atténuation L/R ; centre neutre. Ce n'est pas une rotation de phase. |
| bm_bypass | Fondu vers le signal sec en 5 ms ; une fois établi, signal sec bit-exact. |

## Chaîne et choix numériques

HPF → LPF → couleur grave → médium → aigu → Air → Gravity → EQ corrective → composante d'atténuation grave → stéréo. Les EQ fixes sont linéaires ; leur ordre de cascade ne change pas leur réponse stationnaire. Les interactions des commandes s'additionnent en dB.

Biquads en forme directe I, états et calculs double précision. Coefficients recalculés seulement lorsque les réglages changent, puis interpolés sur 20 ms. Aucune allocation/aucun mutex dans le traitement. Les tests d'automation couvrent les extrêmes de réglage ; cela ne remplace pas une écoute des transitions.

Les fréquences de calcul sont bornées à 0,45 × Fs. Si le LPF demandé dépasse 0,499 × Fs, le filtre devient neutre. Exemple : 38 kHz à 44,1 kHz ne représente pas une coupure réalisable et laisse le signal passer. Le HTML continue à afficher la valeur d'origine. À résoudre explicitement lors du raccordement UI sans changer son design.

Le moteur reste actif en arrière-plan pendant le bypass afin de maintenir ses états. Mono : traitement tonal seul, paramètres stéréo sans effet. Stéréo : Mid=(L+R)/2 et Side=(L−R)/2, puis décodage L=Mid+Side et R=Mid−Side.

Pas d'écrêtage de sécurité ajouté au signal : l'EQ peut dépasser 0 dBFS ; le futur limiteur assurera le contrôle des crêtes. Aucun contrôle actuellement nommé ceiling/ISP/oversampling ne doit être considéré comme opérationnel.

## Courbes reproductibles

`EQ_RESPONSE_48k.csv` et `EQ_CURVES.png` décrivent les coefficients réellement utilisés, à 48 kHz, autres commandes neutres et filtres de coupe désactivés. Générateur : `tools/eq_response.cpp`.

Sources de conception :
- RBJ/W3C Audio EQ Cookbook : https://www.w3.org/TR/audio-eq-cookbook/
- Description des interactions boost/attenuation Pultec : https://help.uaudio.com/hc/en-us/articles/7183176266260-Pultec-Passive-EQ-Collection-Manual

Les fréquences, ratios de couplage et Q choisis pour BloodyMaster sont des choix originaux, à ajuster par écoute lors des étapes suivantes.
