#pragma once
#include "PluginProcessor.h"

// Functional test editor. The approved HTML resources remain untouched.
class BloodyMasterEditor final : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit BloodyMasterEditor(BloodyMasterProcessor&);
    void resized() override;
private:
    BloodyMasterProcessor& processor;
    juce::Label title, status, meters;
    juce::ComboBox presets;
    juce::Viewport viewport;
    juce::Component parameterList;
    std::vector<std::unique_ptr<juce::Component>> rows;
    void timerCallback() override;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(BloodyMasterEditor)
};
