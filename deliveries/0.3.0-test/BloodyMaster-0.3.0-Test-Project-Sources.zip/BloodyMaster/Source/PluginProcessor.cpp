#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "Parameters/ParameterIDs.h"
#include "Parameters/ParameterLayout.h"
#include "Presets/FactoryPresets.h"

void BloodyMasterProcessor::publishMeters() {
    const auto& m=mastering.meters;
    const std::array<double,6> values{m.inputPeak,m.outputPeak,m.compressorGr,m.glueGr,m.clipGr,m.limiterGr};
    for(size_t i=0;i<values.size();++i) meterValues[i].store(static_cast<float>(values[i]),std::memory_order_relaxed);
}
bm::dsp::MeterValues BloodyMasterProcessor::getMeterValues() const {
    return {meterValues[0].load(std::memory_order_relaxed),meterValues[1].load(std::memory_order_relaxed),
            meterValues[2].load(std::memory_order_relaxed),meterValues[3].load(std::memory_order_relaxed),
            meterValues[4].load(std::memory_order_relaxed),meterValues[5].load(std::memory_order_relaxed)};
}

int BloodyMasterProcessor::getNumPrograms() { return static_cast<int>(bm::factoryPresets().size()); }
const juce::String BloodyMasterProcessor::getProgramName(int index) {
    if(index<0 || index>=getNumPrograms()) return {};
    return bm::factoryPresets()[static_cast<size_t>(index)].name;
}
void BloodyMasterProcessor::setCurrentProgram(int index) {
    if(index<0 || index>=getNumPrograms()) return;
    for(const auto& [id,value]:bm::presetParameters(bm::factoryPresets()[static_cast<size_t>(index)].settings))
        if(auto* parameter=apvts.getParameter(id)) parameter->setValueNotifyingHost(parameter->convertTo0to1(value));
    currentProgram.store(index,std::memory_order_relaxed);
}

BloodyMasterProcessor::BloodyMasterProcessor()
    : AudioProcessor(BusesProperties()
                         .withInput("Input", juce::AudioChannelSet::stereo(), true)
                         .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "BloodyMasterState", bm::createParameterLayout())
{
    (void) bm::factoryPresets();
    const std::array<const char*,32> ids {
        bm::id::hpf, bm::id::lpf, bm::id::bass, bm::id::mid, bm::id::high,
        bm::id::presence, bm::id::foundation, bm::id::p1f, bm::id::p2f, bm::id::p3f,
        bm::id::p1g, bm::id::p2g, bm::id::p3g, bm::id::monomaker, bm::id::width,
        bm::id::pan, bm::id::eqActive, bm::id::bypass,
        bm::id::drive, bm::id::squash, bm::id::recovery, bm::id::link, bm::id::mix,
        bm::id::glue, bm::id::valve, bm::id::clipper, bm::id::turbo, bm::id::trim,
        bm::id::limrel, bm::id::limlink, bm::id::isp, bm::id::oversampling
    };
    for (size_t i=0; i<ids.size(); ++i)
        dspParameters[i]=apvts.getRawParameterValue(ids[i]);
}

bm::dsp::EngineSettings BloodyMasterProcessor::readDspSettings() const
{
    const auto v=[&](size_t i) { return static_cast<double>(dspParameters[i]->load(std::memory_order_relaxed)); };
    bm::dsp::EngineSettings settings;
    auto& s=settings.tone;
    s.hpf=v(0); s.lpf=v(1)*1000; s.bass=v(2); s.mid=v(3); s.high=v(4);
    s.presence=v(5); s.body=v(6);
    for(size_t i=0;i<3;++i) { s.freq[i]=v(7+i); s.gain[i]=v(10+i); }
    s.monoBass=v(13); s.width=v(14); s.balance=v(15); s.eq=v(16)>.5; s.bypass=v(17)>.5;
    settings.bypass=v(17)>.5;
    settings.oversampling=2 << juce::jlimit(0,2,static_cast<int>(v(31)));
    auto& d=settings.dynamics;
    d.drive=v(18); d.ratio=v(19); d.releaseMs=v(20); d.link=v(21); d.mix=v(22); d.glue=v(23); d.optical=v(24)>.5;
    auto& p=settings.peaks;
    p.clipDb=v(25); p.pushDb=v(26); p.ceilingDb=v(27); p.releaseMs=v(28); p.link=v(29); p.isp=v(30)>.5;
    return settings;
}

void BloodyMasterProcessor::prepareToPlay(double sampleRate, int)
{
    const auto settings=readDspSettings();
    mastering.prepare(sampleRate,settings.oversampling);
    mastering.update(settings);
    setLatencySamples(mastering.latency());
}

bool BloodyMasterProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto& in  = layouts.getMainInputChannelSet();
    const auto& out = layouts.getMainOutputChannelSet();
    if (in != out) return false;
    return out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo();
}

void BloodyMasterProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    // Les canaux de sortie sans entree correspondante sont mis a zero (pas de bruit residuel).
    for (int ch = getTotalNumInputChannels(); ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear(ch, 0, buffer.getNumSamples());

    mastering.update(readDspSettings());
    mastering.process(buffer.getArrayOfWritePointers(), buffer.getNumChannels(), buffer.getNumSamples());
    publishMeters();
}

void BloodyMasterProcessor::processBlockBypassed(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    auto s=readDspSettings(); s.bypass=true;
    mastering.update(s);
    mastering.process(buffer.getArrayOfWritePointers(),buffer.getNumChannels(),buffer.getNumSamples());
    publishMeters();
}

juce::AudioProcessorEditor* BloodyMasterProcessor::createEditor()
{
    return new BloodyMasterEditor(*this);
}

juce::AudioProcessorParameter* BloodyMasterProcessor::getBypassParameter() const
{
    return apvts.getParameter(bm::id::bypass);
}

void BloodyMasterProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml()) {
        xml->setAttribute("factoryProgram",getCurrentProgram());
        copyXmlToBinary(*xml, destData);
    }
}

void BloodyMasterProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary(data, sizeInBytes))
        if (xml->hasTagName(apvts.state.getType())) {
            currentProgram.store(juce::jlimit(0,getNumPrograms()-1,xml->getIntAttribute("factoryProgram",0)),std::memory_order_relaxed);
            apvts.replaceState(juce::ValueTree::fromXml(*xml));
        }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new BloodyMasterProcessor();
}
